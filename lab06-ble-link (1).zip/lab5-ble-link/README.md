# Lab 5 (Task 5) — Measuring the Bluetooth LE link

Code for Task 5 of Lecture 6 (Lab 5a, Lab 5b): two ESP32-S3-DevKitC-1 boards and a NUCLEO-F401RE measure the signal strength (RSSI) of a Bluetooth LE link.

- **Board A** (ESP32-S3) advertises as `LAB5-A` at a transmit power set with the BOOT button.
- **Board B** (ESP32-S3) scans, reads the RSSI of every advertisement from Board A and sends it to the STM32 over UART1.
- **NUCLEO-F401RE** collects 20 readings, takes the median and prints one line per distance to the console.

> **Status:** the code is written but has not been run on hardware. The ESP32 Arduino core (esp32 by Espressif 3.3.x) would not compile on my Windows laptop, so the ESP32 boards could not be flashed and no measurements were taken. See the lab report for details.

## Repository layout

```
esp32/lab06_board_A/lab06_board_A.ino   Board A: BLE advertiser, TX power steps
esp32/lab06_board_B/lab06_board_B.ino   Board B: BLE scanner, RSSI frames to STM32
stm32/Core/Src/main.c                   NUCLEO-F401RE: frame parser, median of 20
analysis/analyze.py                     Power-sweep slope, path-loss exponent n, fading dips
data/                                   CSV templates (empty) and example_*.csv (simulated, not measured)
```

## Hardware setup

```
Board A ))) over the air, 0.5-16 m ))) Board B ===UART1, 3 wires=== NUCLEO-F401RE ===USB=== laptop
   |                                      |
lab power supply 5 V                     USB (laptop)
```

**UART1 link, 115200 8N1**

| NUCLEO-F401RE | Direction | ESP32-S3 Board B |
| --- | --- | --- |
| D8 / PA9 (USART1_TX) | → | GPIO18 (RX) |
| D2 / PA10 (USART1_RX) | ← | GPIO17 (TX) |
| GND | — | GND |

- TX goes to RX crosswise; the shared GND is required.
- Both boards use 3.3 V logic. Do not join the 5V or 3V3 pins: each board has its own supply.
- Nucleo D0/D1 are **not** used: they belong to USART2, the ST-LINK console.
- The DevKitC-1 pins labelled RX/TX are GPIO44/43 (UART0, used by the USB port). This lab uses GPIO18/17.

**Power**

- Nucleo and Board B: USB from the laptop (Board B on the port labelled "UART").
- Board A: laboratory power supply, + to the **5V** pin and − to **GND**, 5.0 V, 0.5 A current limit. Flash it over USB first, then unplug USB so there is only one supply.

**Placement:** both boards on non-metal stands at the same height and orientation, PCB antenna ends clear, leads and laptop to the side, operator standing back.

## UART frame (Board B → STM32)

| Byte | Value |
| --- | --- |
| 0 | `0xAA` start |
| 1 | `0x01` length |
| 2 | RSSI, signed 8-bit (dBm) |
| 3 | checksum = length XOR RSSI |

## Building

### ESP32 boards (Arduino IDE)

1. Boards Manager: install **esp32 by Espressif Systems**.
2. Tools → Board → **ESP32S3 Dev Module**, Tools → Port → the board's COM port (USB port labelled "UART").
3. Open `lab06_board_A.ino`, Upload. Then the same for `lab06_board_B.ino` on Board B.
4. If upload fails with "Failed to connect": hold BOOT, press and release RST, release BOOT, try again.

### NUCLEO-F401RE (STM32CubeMX + STM32CubeIDE)

1. STM32CubeMX → New Project → Board Selector → **NUCLEO-F401RE** → initialise peripherals in default mode: **Yes**.
2. Connectivity → **USART1** → Mode: Asynchronous, 115200, 8N1. Check PA9 = USART1_TX, PA10 = USART1_RX.
3. USART1 → NVIC Settings → enable **USART1 global interrupt**.
4. USART2 (ST-LINK console) stays enabled at 115200.
5. Project Manager → Toolchain / IDE: **STM32CubeIDE** → Generate Code → open in STM32CubeIDE.
6. Replace `Core/Src/main.c` with the file from this repository (or copy the USER CODE sections), build and run.

## Using it

1. Open a serial terminal on the ST-LINK virtual COM port at 115200 and reset the Nucleo: `Lab 5 ready. B1 = next distance.`
2. Every 20 readings it prints a line such as `d=4.0 m  n=20  med=-54.0`.
3. **Power sweep (5a):** Board A at 1 m. Reset Board A (−24 dBm), then press BOOT once per step (+3 dB, up to +18 dBm). After each press, skip the first median and record the second.
4. **Distance sweep (5a):** reset Board A and press BOOT 8 times (0 dBm). Use the blue button **B1** on the Nucleo to select 0.5, 1, 2, 4, 8 or 16 m, place Board A, record the median. Repeat in the corridor and outdoors.
5. **Fading scan (5b):** Board A fixed, Board B moved along a ruler in 1 cm steps over 12 cm; record the median at each step.

## Analysis

Fill in the CSV files in `data/`, then:

```
cd analysis
python analyze.py power    ../data/power_sweep.csv      # slope in dB/dB, expected 1
python analyze.py distance ../data/distance_sweep.csv   # n for each place, flags > 3 dB misfits
python analyze.py fading   ../data/fading_scan.csv      # dips, spacing vs lambda/2 (6.1 cm), fade margin
```

Add `--plot` to draw the graph (needs `matplotlib`). The `example_*.csv` files hold simulated values that follow the Lecture 6 models, so the script can be tried before real data exists. They are **not** measurements.

Model used: `RSSI(d) = RSSI(1 m) − 10 n log10(d)`; the slope against log10(d) is −10n.
